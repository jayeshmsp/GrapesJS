module.exports = {

  textTags: ['br', 'b', 'i', 'u', 'a', 'ul', 'ol'],

};
