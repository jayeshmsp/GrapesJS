module.exports = {

  devices: [],

  deviceLabel: 'Device',

};
