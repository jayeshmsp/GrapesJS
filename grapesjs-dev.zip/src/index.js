module.exports = require('./grapesjs');
