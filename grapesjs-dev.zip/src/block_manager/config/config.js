module.exports = {

  blocks: [],

  appendTo: '',

};
